﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyApp.Core
{
    public interface IEngine
    {
        void Run();
    }
}
