﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Minions
{
    public class Configuration
    {
        public const string connectionString = @"Server=LAPTOP-5SU6O5P6\SQLEXPRESS;Database=MinionsDB;Integrated Security=True";
    }
}
