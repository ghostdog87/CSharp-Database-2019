﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=LAPTOP-5SU6O5P6\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
