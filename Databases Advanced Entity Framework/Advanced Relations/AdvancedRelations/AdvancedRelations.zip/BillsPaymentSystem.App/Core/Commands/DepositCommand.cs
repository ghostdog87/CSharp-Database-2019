﻿using BillsPaymentSystem.App.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Text;


namespace BillsPaymentSystem.App.Core.Commands
{
    public class DepositCommand : ICommand
    {
        public string Execute(string[] Args)
        {
            throw new NotImplementedException();
        }
    }
}
