﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillsPaymentSystem.Data
{
    public class Config
    {
        public static string connectionString = @"Server=LAPTOP-5SU6O5P6\SQLEXPRESS;Database=BillsPaymentSystem;Integrated Security=True;";
    }
}
