﻿namespace FastFood.Web.ViewModels.Categories
{
    public class CreateCategoryInputModel
    {
        public string CategoryName { get; set; }
    }
}
