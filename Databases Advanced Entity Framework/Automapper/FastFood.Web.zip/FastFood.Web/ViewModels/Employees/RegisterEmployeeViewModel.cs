﻿namespace FastFood.Web.ViewModels.Employees
{
    public class RegisterEmployeeViewModel
    {
        public int PositionId { get; set; }
    }
}
